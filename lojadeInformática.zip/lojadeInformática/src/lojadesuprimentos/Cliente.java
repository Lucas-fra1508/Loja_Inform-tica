/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lojadesuprimentos;

/**
 *
 * @author lucas
 */
public class Cliente extends Pessoa{
    private int telefone;
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    public void cadastro(){
        Cliente objcliente = new Cliente();
        objcliente.setNome("Lucas");
        objcliente.setIdade(27);
        objcliente.setCpf(123);
        objcliente.setTelefone(0000);
                
        
        System.out.println(objcliente.getNome());
        System.out.println(objcliente.getIdade());
        System.out.println(objcliente.getCpf());
        System.out.println(objcliente.getTelefone());
    }

    /**
     * @return the telefone
     */
       
    
}
