/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lojadesuprimentos;

/**
 *
 * @author lucas
 */

public class Empregado extends Pessoa{
    private int telefone;
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    public void cadastro(){
        Empregado objempregado = new Empregado();
        objempregado.setNome("Lucas");
        objempregado.setIdade(27);
        objempregado.setCpf(123);
        objempregado.setTelefone(0000);
                
        
        System.out.println(objempregado.getNome());
        System.out.println(objempregado.getIdade());
        System.out.println(objempregado.getCpf());
        System.out.println(objempregado.getTelefone());
    }

    /**
     * @return the telefone
     */
       
    
}
