/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lojadesuprimentos;

import java.util.Scanner;

/**
 *
 * @author lucas
 */

public class Fornecedor extends Pessoa{
    private int telefone;
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {//valorar os atributos
        java.util.Scanner objfornecedor = new Scanner(System.in);
        String Nomefornecedor, Endfornecedor;//Variaveis
        int cpf;
        System .out.print("Entre com o nome do fornecedor \n");//escreva
        Nomefornecedor = objfornecedor.nextLine();//Leia 
        System.out.print("Entre com o endereço do fornecedor \n");
        Endfornecedor = objfornecedor.nextLine();
        System.out.print("Entre com o Cpf do fornecedor \n");
        cpf = objfornecedor.nextInt();
        System.out.print("\n O nome do fornecedor :" + Nomefornecedor + ".");
        System.out.print("\n Endereco fornecedor : " + Endfornecedor + ".");
        System.out.print("\n O cpf do fornecedor: " + cpf + "\n\n");
        
    }
        
        
    }