
package lojadesuprimentos;

public class Lojadesuprimentos {


    public static void main(String[] args) {
        Cliente cliente = new Cliente();
        cliente.cadastro();
    }
    
}
