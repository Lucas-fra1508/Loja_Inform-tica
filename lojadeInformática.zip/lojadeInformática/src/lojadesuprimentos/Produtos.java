/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lojadesuprimentos;

public class Produtos {

    private int Nome;
    private int Id;
    private int Descricao;
    private int Marca;
    private int Setor;
    private int Fornecedor;

    /**
     * @return the Nome
     */
    public int getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(int Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }

    /**
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }

    /**
     * @return the Descricao
     */
    public int getDescricao() {
        return Descricao;
    }

    /**
     * @param Descricao the Descricao to set
     */
    public void setDescricao(int Descricao) {
        this.Descricao = Descricao;
    }

    /**
     * @return the Marca
     */
    public int getMarca() {
        return Marca;
    }

    /**
     * @param Marca the Marca to set
     */
    public void setMarca(int Marca) {
        this.Marca = Marca;
    }

    /**
     * @return the Setor
     */
    public int getSetor() {
        return Setor;
    }

    /**
     * @param Setor the Setor to set
     */
    public void setSetor(int Setor) {
        this.Setor = Setor;
    }

    /**
     * @return the Fornecedor
     */
    public int getFornecedor() {
        return Fornecedor;
    }

    /**
     * @param Fornecedor the Fornecedor to set
     */
    public void setFornecedor(int Fornecedor) {
        this.Fornecedor = Fornecedor;

    }

    public void produtos() {
        Produtos objproduto = new Produtos();
        objproduto.setId(Id);
        objproduto.setDescricao(Descricao);
        objproduto.setMarca(getMarca());
        objproduto.setSetor(getSetor());
        objproduto.setFornecedor(getFornecedor());

        System.out.println(objproduto.getId());
        System.out.println(objproduto.getDescricao());
        System.out.println(objproduto.getMarca());
        System.out.println(objproduto.getSetor());
        System.out.println(objproduto.getFornecedor());
    }

}
